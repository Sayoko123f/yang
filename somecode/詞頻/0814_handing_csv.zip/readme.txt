src.csv = 原始檔案
out1.csv = 1個中文字長度
out2.csv = 2個中文字長度
out3.csv = 3個中文字長度
out4.csv = 非以上中文字長度

out5.csv = 含特殊字元被過濾掉的詞
過濾規則regex：
/(?!\p{Han}+).+/u